void main(){
  int integer1 = 3;
  double double1 = 0.23;
  String sting1 = 'Hello World!';
}