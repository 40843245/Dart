void main(){
  const primaryColors = [
    Color('red', [255, 0, 0]),
    Color('green', [0, 255, 0]),
    Color('blue', [0, 0, 255]),
  ];
}