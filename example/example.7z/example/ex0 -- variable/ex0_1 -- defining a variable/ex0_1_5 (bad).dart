void main(){
    const primaryColors = const [
    const Color('red', const [255, 0, 0]),
    const Color('green', const [0, 255, 0]),
    const Color('blue', const [0, 0, 255]),
  ];
}