void main(){
  // Declare a variable without a type or assigned value
  // and Dart infers the 'dynamic' type
  var name;
  // Initialize the variable and the type remains `dynamic`
  name = 'bob';
  name = 5; // Allowed, as `name` has type `dynamic`.
}