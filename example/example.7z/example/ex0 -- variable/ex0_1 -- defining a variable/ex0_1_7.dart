void main(){
  bool useNickname = false;
  final String name;
  // Cannot read name here, not initialized.
  if (useNickname) {
    name = "Bob";
  } else {
    name = "Robert";
  }
  print(name); // Properly initialized here.
}