void main(){
  var foo = const [];
  // foo is not constant, but the value it points to is.
  // You can reassign foo to a different list value,
  // but its current list value cannot be altered.

  const baz = []; // Equivalent to `const []`
}