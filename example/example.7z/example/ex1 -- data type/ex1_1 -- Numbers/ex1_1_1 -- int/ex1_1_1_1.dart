void main(){
  var integer1 = 1;
  var hexInteger1 = 0xDEADBEEF;
}