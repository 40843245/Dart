void main(){
  var double1 = 1.1;
  var double2WithExponentRepresentation = 1.42e5;
  double z = 1; // equivalent to double z = 1.0.
}