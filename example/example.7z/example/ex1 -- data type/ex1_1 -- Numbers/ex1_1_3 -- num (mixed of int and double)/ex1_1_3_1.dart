void main(){
  num x = 1; // x can have both int and double values
  x += 2.5;
}