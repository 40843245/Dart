/*

You can use one or more underscores (_) as digit separators to make long number literals more readable. 
Multiple digit separators allow for higher level grouping.

> [!WARNING]
> Version note
>
> Using digit separators requires a language version of at least `3.6.0`.
*/

// am example of a number with digit sepearator
void main(){
  var n1 = 1_000_000;
  var n2 = 0.000_000_000_01;
  var n3 = 0x00_14_22_01_23_45;  // MAC address
  var n4 = 555_123_4567;  // US Phone number
  var n5 = 100__000_000__000_000;  // one hundred million million!
}