void main(){
  bool tf1 = false;
  bool tf2 = true;
  bool tf3; 
}