void main(){
  #radix
  #bar
}