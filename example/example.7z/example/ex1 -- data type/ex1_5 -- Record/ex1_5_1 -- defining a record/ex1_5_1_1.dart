void main(){
  var record = ('first', a: 2, b: true, 'last');
}