void main(){
  // Record type annotation in a variable declaration:
  (String, int) record1;

  // Initialize it with an assignment of record expression.
  record1 = ('A string', 123);
}