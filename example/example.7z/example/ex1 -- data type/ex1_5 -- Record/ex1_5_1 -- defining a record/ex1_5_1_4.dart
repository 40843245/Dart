void main(){
  // Record type annotation in a variable declaration:
  ({int a, bool b}) record;

  // Initialize it with a record expression:
  record = (a: 123, b: true);
}