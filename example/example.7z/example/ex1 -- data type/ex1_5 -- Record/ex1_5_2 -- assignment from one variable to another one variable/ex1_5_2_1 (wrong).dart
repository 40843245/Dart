void main(){
  // About record variable with naming named fields,the type will be considered to be different when their names are different since these names are purely for documentation.
  ({int a, int b}) recordAB = (a: 1, b: 2);
  ({int x, int y}) recordXY = (x: 3, y: 4);

  // Compile error! These records don't have the same type.
  // recordAB = recordXY;
}