void main(){
  // About record variable with naming positional fields,the type will be considered to be same when their names are different since these names are purely for documentation.
  (int a, int b) recordAB = (1, 2);
  (int x, int y) recordXY = (3, 4);

  recordAB = recordXY; // OK.
}