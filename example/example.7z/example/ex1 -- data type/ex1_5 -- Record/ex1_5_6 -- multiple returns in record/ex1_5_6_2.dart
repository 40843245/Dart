// Returns multiple values in a record:
({String name, int age}) userInfo(Map<String, dynamic> json) {
  return (json['name'] as String, json['age'] as int);
}

void main(){
  // Destructures using a record pattern with named fields:
  final (:name, :age) = userInfo(json);
}