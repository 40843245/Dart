void main(){
  var list1 = [1, 2, 3];
  List<Int> list2 = [1, 2, 3];

  // a trailing comma at last element is also ok.
  var list3 = [
    'Car',
    'Boat',
    'Plane',
  ];

  List<String> list4 = [
    'Car',
    'Boat',
    'Plane',
  ];
}