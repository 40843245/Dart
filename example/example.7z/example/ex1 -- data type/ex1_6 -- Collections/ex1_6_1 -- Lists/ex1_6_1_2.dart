// an example of a List<T> that's a compile-time constant.
void main(){
  // To create a List<T> that's a compile-time constant, add const before the list literal (such as const [ /* ... */ ]).
  var constantList = const [1, 2, 3];
  // constantList[1] = 1; // This line will cause an error.
}