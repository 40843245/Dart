// an example of a List<T> that's a is not compile-time constant, but is immutable.
void main(){
  // To create a List<T> that's a is not compile-time constant, but is immutable. Use List<T>.unmodifable constructor
  final _list1 = List<String>.unmodifiable(['a', 'b', 'c']);

  // _list1[1] = 1; // This line will cause an error.
}