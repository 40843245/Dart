void main(){
  var set1 = {'fluorine', 'chlorine', 'bromine', 'iodine', 'astatine'};
  Set<String> set2 = {'fluorine', 'chlorine', 'bromine', 'iodine', 'astatine'};
}