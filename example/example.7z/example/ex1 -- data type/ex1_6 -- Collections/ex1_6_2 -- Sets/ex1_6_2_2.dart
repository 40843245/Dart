// an example of instantiating an empty Set<String>.
void main(){
var set1 = <String>{};
var set2 = Set<String>{};
Set<String> set3 = {}; // This works, too.
// var set3 = {}; // NOPE!!! It will instantiate an empty map, not a set.
}