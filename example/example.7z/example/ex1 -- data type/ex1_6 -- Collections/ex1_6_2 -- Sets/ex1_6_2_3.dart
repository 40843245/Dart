// an example of a Set<T> that's a compile-time constant.
void main(){
  // To create a Set<T> that's a compile-time constant, add const before the set literal (such as const const{ /* ... */ } ).
  final constantSet = const {
    'fluorine',
    'chlorine',
    'bromine',
    'iodine',
    'astatine',
  };
  // constantSet.add('helium'); // This line will cause an error.
}