// an example of a Set<T> that's a is not compile-time constant, but is immutable.
void main(){
  // To create a Set<T> that's a is not compile-time constant, but is immutable. Use Set<T>.unmodifable constructor
  final _set1  = Set<String>.unmodifiable(['a', 'b', 'c']);

  // _set1[1] = 1; // This line will cause an error.
}