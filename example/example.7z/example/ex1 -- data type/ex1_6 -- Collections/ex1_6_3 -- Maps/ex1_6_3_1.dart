void main(){
  var gifts1 = {
    // Key:    Value
    'first': 'partridge',
    'second': 'turtledoves',
    'fifth': 'golden rings'
  };

  Map<String, String> gifts2 = {
    // Key:    Value
    'first': 'partridge',
    'second': 'turtledoves',
    'fifth': 'golden rings'
  };

  var gifts3 = Map<String, String>();
  gifts3['first'] = 'partridge';
  gifts3['second'] = 'turtledoves';
  gifts3['fifth'] = 'golden rings';

  Map<String, String>() gifts4;
  gifts4['first'] = 'partridge';
  gifts4['second'] = 'turtledoves';
  gifts4['fifth'] = 'golden rings';

  var gifts5 = <String, String>{};
  gifts5['first'] = 'partridge';
  gifts5['second'] = 'turtledoves';
  gifts5['fifth'] = 'golden rings';
}