// an example of a Map<T1,T2> that's a compile-time constant.
void main(){
  // To create a Map<T1,T2> that's a compile-time constant, add const before the map literal (such as const const{ /* ... */ } ).
  final constantMap = const {
    2: 'helium',
    10: 'neon',
    18: 'argon',
  };

  // constantMap[2] = 'Helium'; // This line will cause an error.
}