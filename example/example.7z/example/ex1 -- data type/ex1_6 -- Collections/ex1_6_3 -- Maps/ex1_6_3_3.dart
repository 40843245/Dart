// an example of a Map<K,V> that's a is not compile-time constant, but is immutable.
void main(){
  // To create a Map<K,V> that's a is not compile-time constant, but is immutable. Use Map<K,V>.unmodifable constructor
  final _map1 = Map<String, String>.unmodifiable({'foo': 'bar'});

  // _map1[1] = 1; // This line will cause an error.
}