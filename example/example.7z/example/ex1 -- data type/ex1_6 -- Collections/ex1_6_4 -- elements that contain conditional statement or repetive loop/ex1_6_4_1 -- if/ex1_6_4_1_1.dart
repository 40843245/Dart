void main(){
  // a List<String> with three or four elements.
  var nav = ['Home', 'Furniture', 'Plants', if (promoActive) 'Outlet'];
}