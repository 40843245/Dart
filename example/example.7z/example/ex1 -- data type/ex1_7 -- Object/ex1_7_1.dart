void main(){
  Object name = 'Bob';
}