/*
  `?` followed by a keyword for any type indicates the following variable is a nullable variable (i.e. the variable can be assigned with null value). Like in Kotlin.
*/
void main(){
  int? nullableInteger1 = 4; // defines a nullable variable -- `nullableInteger1` with nullable int type. 
}