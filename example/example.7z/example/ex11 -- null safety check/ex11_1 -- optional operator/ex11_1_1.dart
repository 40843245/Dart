/*
  `?.` optional operator, like `?.` optional operator in Kotlin.
*/ 

import 'dart:math';

void main(){
  var p1 = Point(2, 2);
  var p1y = p1?.y; // if p1 is non-null, `ply` equals to `pl.y1`. otherwsie, `ply` equals to null. 
}