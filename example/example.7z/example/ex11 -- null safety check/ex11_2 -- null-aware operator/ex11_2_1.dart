/*
  `??` null-aware operator.
*/ 

void main(){
  bool nullableBool;
  // If you want null to result in false:
  if (nullableBool ?? false) {
    print("${nullableBool} is either null or false.")
  }

  // If you want null to result in false
  // and you want the variable to type promote:
  if (nullableBool != null && nullableBool) { 
      print("${nullableBool} is either null or false.")
  }
}