/*
  `!` followed by a variable is a null-check operator, like `!!` in Kotlin.
*/

void main(){
  bool? nullableBool;
  bool nonNullableBool = nullableBool!; // raises runtime error when [nullableBool] is null.
}