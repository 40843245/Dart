class Animal{
  String name;
  double weight;
  double height;
  
  Animal(this.name,this.weight,this.height);

  double bmi(){
    return this.weight / ( this.height * this.height );
  }
}

class People extends Animal(){
  
  String say(String message){
    return 'A person ${this.name} says ${message}';
  }
}