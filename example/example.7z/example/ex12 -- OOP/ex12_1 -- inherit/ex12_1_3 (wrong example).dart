base class Vehicle {
  void moveForward(int meters) {
    // ...
  }
}

// Can be extended.
base class Car extends Vehicle {
  int passengers = 4;
  // ...
}

// ERROR: Can't be implemented.
base class MockVehicle implements Vehicle {
  @override
  void moveForward() {
    // ...
  }
}

void main(){
  // Can be constructed.
  Vehicle myVehicle = Vehicle();
}