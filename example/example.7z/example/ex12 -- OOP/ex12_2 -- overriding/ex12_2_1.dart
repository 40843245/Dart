class Animal{
  String name;
  double weight;
  double height;
  
  Animal(this.name,this.weight,this.height){

  }

  String getName(){
    return this.name;
  }

  double getBmi(){
    return this.weight / ( this.height * this.height );
  }

  String say(String message){
    return 'An animal ${this.name} says ${message}';
  }
}

class People extends Animal(){

  /// method overriding
  @overriding  
  String say(String message){
    return '${super.say(message)}\nA person ${this.name} says ${message}';
  }
}