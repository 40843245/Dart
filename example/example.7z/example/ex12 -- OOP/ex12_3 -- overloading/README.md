# NOTICE
In Kotlin, one can define two function or methods with same name but with different parameter list.

However, there are no overloading in Dart stated in [`this article`](https://dart.dev/effective-dart/design#avoid-using-runtime-type-tests-to-fake-overloading)