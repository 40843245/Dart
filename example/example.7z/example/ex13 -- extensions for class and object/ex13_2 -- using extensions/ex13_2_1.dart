import 'string_apis.dart';

void main(){
  print('42'.parseInt()); // Use an extension method.
}
