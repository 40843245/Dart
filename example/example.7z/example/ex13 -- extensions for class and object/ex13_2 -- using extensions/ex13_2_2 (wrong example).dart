import 'string_apis.dart';
void main(){
  dynamic d = '2';
  print(d.parseInt()); // raise Runtime exception: NoSuchMethodError
}
