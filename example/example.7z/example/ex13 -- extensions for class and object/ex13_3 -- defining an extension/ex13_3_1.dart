// place in `lib/string_apis.dart`

extension NumberParsing on String {
  int parseInt() {
    return int.parse(this);
  }
}

// place in `lib/string_apis_2.dart`

extension NumberParsing2 on String {
  int parseInt() {
    return int.parse(this);
  }
}

// place in `lib/string_apis_3.dart`

extension NumberParsing on String {
  int parseInt() {
    return int.parse(this);
  }

  double parseNum(){
    return double.parse(this);
  }
}