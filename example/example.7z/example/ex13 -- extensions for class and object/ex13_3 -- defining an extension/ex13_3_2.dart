extension on String {
  bool get isBlank => trim().isEmpty;
}