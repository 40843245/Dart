// Defines the String extension method parseInt().
import 'string_apis.dart';

// Also defines parseInt(), but hiding NumberParsing2
// hides that extension method with name `NumberParsing2` when importing.
import 'string_apis_2.dart' hide NumberParsing2;

void main(){
  // Uses the parseInt() defined in 'string_apis.dart'.
  print('42'.parseInt());
}