# reference
## guide reference
See [`Extension methods`](https://dart.dev/language/extension-methods)