extension type E._(int i) {
  E.fromString(String foo) : i = int.parse(foo);
}