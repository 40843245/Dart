# reference
## guide reference
See [`Extension types`](https://dart.dev/language/extension-types)