class NumberManager<T extends num> {
   
}
// Valid.
var manager1 = NumberManager<int>();
var manager2 = NumberManager<double>();

// Invalid, String nor its parent classes extend num.
// var manager = NumberManager<String>();