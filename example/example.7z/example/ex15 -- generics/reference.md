# reference
## guide reference
See [`Generics`](https://dart.dev/language/generics)