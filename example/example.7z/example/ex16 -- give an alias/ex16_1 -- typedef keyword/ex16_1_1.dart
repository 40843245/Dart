typedef IntList = List<int>;

void main(){
  IntList il = [1, 2, 3];
}