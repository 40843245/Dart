/*

> [!WARNING]
> Version note:
> 
> Before 2.13, typedefs were restricted to function types. 
> 
> Using the new typedefs requires a language version of at least 2.13.

*/
// an example of use of `typedef` keyword
typedef ListMapper<X> = Map<X, List<X>>;

void main(){
  Map<String, List<String>> m1 = {}; // Verbose.
  ListMapper<String> m2 = {}; // Same thing but shorter and clearer.
}