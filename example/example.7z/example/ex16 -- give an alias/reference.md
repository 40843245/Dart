# reference
## guide reference
See [`Typedefs`](https://dart.dev/language/typedefs)