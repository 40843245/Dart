// a good example
void main(){
  // Creates a List<int>:
  var iterable = [1, 2, 3];

  // Prints "List<int>":
  print(iterable.toList().runtimeType);
}