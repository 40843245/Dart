// a bad example
void main(){
  // Creates a List<int>:
  var iterable = [1, 2, 3];

  // Prints "List<dynamic>":
  print(List.from(iterable).runtimeType);
}