// a good example
void main(){
  var numbers = [1, 2.3, 4]; // List<num>.
  numbers.removeAt(1); // Now it only contains integers.
  var ints = List<int>.from(numbers);
}