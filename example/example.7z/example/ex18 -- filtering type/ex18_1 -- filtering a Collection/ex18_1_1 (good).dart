// a good example
void main(){
  var objects = [1, 'a', 2, 'b', 3];
  var ints = objects.whereType<int>();
}