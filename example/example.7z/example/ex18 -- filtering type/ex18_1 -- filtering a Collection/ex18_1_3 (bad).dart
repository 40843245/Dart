// a bad example
void main(){
  var objects = [1, 'a', 2, 'b', 3];
  var ints = objects.where((e) => e is int).cast<int>();
}