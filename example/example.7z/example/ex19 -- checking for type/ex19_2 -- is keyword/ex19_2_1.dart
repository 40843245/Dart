void main(){
  int integer1 = 4;
  if(integer1 is int){
    print('$integer1 is an int type');
  }else{
    print('$integer1 is not an int type');
  }
}