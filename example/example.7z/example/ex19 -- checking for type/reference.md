# reference
## guide reference
See [`Collections`](https://dart.dev/language/collections)

