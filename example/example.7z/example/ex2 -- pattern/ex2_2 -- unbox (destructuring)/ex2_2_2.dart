void main(){
  switch (list) {
    case ['a' || 'b', var c]:
      print(c);
  }
}