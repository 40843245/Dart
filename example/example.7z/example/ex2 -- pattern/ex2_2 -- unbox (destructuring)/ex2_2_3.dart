void main(){
  var (a, b) = ('left', 'right');
  (b, a) = (a, b); // Swap.
  print('$a $b'); // Prints "right left".
}