void main(){
  var json = {
    'user': ['Lily', 13]
  };
  var {'user': [name, age]} = json;

  if (json case {'user': [String name, int age]}) {
    print('User $name is $age years old.');
  }
}