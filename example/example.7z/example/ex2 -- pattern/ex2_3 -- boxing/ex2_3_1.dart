void main(){
  // Declares new variables a, b, and c.
  var (a, [b, c]) = ('str', [1, 2]); // boxing
}