// a good example of creating it with the right type.
List<int> singletonList(int value) {
  var list = <int>[];
  list.add(value);
  return list;
}