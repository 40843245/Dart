Future<int> fastestBranch(Future<int> left, Future<int> right) {
  return Future.any([left, right]);
}