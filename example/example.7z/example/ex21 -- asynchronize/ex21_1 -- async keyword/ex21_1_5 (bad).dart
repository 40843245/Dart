Future<int> fastestBranch(Future<int> left, Future<int> right) async {
  return Future.any([left, right]);
}