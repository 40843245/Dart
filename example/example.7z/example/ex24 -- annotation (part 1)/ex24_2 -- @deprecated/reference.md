# reference
## API reference
See [`Deprecated class`](https://api.dart.dev/dart-core/Deprecated-class.html)