# reference
## API reference
See [`override top-level constant`](https://api.dart.dev/dart-core/override-constant.html)