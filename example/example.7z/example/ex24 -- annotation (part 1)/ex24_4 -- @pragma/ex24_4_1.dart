@pragma('Tool:pragma-name', [param1, param2, ...])
class Foo { 

}

@pragma('OtherTool:other-pragma')
void foo() { 

}