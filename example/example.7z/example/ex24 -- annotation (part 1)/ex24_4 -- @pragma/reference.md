# reference
## API reference
See [`pragma class`](https://api.dart.dev/dart-core/pragma-class.html)