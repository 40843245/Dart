Stream<int> countStream(int to) async* {
  for (int i = 1; i <= to; i++) {
      yield i;
  }
}

Future<int> lastPositive(Stream<int> stream) => stream.lastWhere((x) => x >= 0);

void main(){
  var stream = countStream(5);
  var result = lastPositive(stream);
  print(result)
}