# reference
## guide reference
See [`Asynchronous programming: Streams`](https://dart.dev/libraries/async/using-streams)

## API reference
See [`Stream<T> class`](https://api.dart.dev/dart-async/Stream-class.html)