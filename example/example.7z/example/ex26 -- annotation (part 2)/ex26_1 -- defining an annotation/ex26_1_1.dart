class Todo {
  final String who;
  final String what;

  /// defining a new annoation [Todo] which takes two arguments [who] and [what]
  const Todo(this.who, this.what);
}