void main(){
  Object anObject = 'Bob';
  var tea = 'red tea';
  
  print(anObject);
  print('I drink $tea.');
}