void main(){
  // This list should contain only strings.
  var fruits = <String>[];

  fruits.add('apples');
  
  var fruit = fruits[0];
  
  assert(fruit is String);
}