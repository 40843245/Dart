# reference
## guide reference
See [`dart:core library`](https://dart.dev/libraries/dart-core)