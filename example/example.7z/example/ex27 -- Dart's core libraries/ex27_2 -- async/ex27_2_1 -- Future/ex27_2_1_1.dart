void main(){
  var httpClient = HttpClient(
    //...
  )
  httpClient.read(url).then((String result) {
  print(result);
  }).catchError((e) {
    // Handle or ignore the error.
  });
}