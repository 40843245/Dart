void main(){
  try {
    final value = await costlyQuery(url);
    await expensiveWork(value);
    await lengthyComputation();
    print('Done!');
  } catch (e) {
    /* Handle exception... */
  }
}