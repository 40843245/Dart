void main(){
  Future<void> deleteLotsOfFiles() async =>  ...
  Future<void> copyLotsOfFiles() async =>  ...
  Future<void> checksumLotsOfOtherFiles() async =>  ...

  await Future.wait([
    deleteLotsOfFiles(),
    copyLotsOfFiles(),
    checksumLotsOfOtherFiles(),
  ]);
  print('Done with all the long steps!');
}