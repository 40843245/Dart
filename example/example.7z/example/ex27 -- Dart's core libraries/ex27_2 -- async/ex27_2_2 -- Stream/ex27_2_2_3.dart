void main(){
  // Add an event handler to a button.
  submitButton.onClick.listen((e) {
    // When the button is clicked, it runs this code.
    submitData();
  });
}