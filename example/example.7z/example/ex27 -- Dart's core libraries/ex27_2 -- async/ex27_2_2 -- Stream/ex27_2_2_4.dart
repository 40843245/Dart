void main(){
  var lines = inputStream.transform(utf8.decoder).transform(const LineSplitter());
}