void main(){
  assert(min(1, -1000) == -1000);
}