void main(){
  assert(max(1, 1000) == 1000);
}