# reference
## guide reference
See [`dart:math library`](https://dart.dev/libraries/dart-math)