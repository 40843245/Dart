# reference
## guide reference
See [`dart:convert library`](https://dart.dev/libraries/dart-convert)