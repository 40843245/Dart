void main(){
  var logFile = File('log.txt');
  var sink = logFile.openWrite(mode: FileMode.append);
  sink.write('FILE ACCESSED ${DateTime.now()}\n');
  await sink.flush();
  await sink.close();
}