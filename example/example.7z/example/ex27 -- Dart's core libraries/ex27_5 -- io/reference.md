# reference
## guide reference
See [`dart:io library`](https://dart.dev/libraries/dart-io)