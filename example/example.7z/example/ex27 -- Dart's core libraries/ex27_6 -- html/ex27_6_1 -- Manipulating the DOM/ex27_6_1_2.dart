void main(){
  // In Dart:
  const osList = ['macos', 'windows', 'linux'];
  final userOs = determineUserOs();

  // For each possible OS...
  for (final os in osList) {
    // Matches user OS?
    bool shouldShow = (os == userOs);

    // Find all elements with class=os. For example, if
    // os == 'windows', call querySelectorAll('.windows')
    // to find all elements with the class "windows".
    // Note that '.$os' uses string interpolation.
    for (final elem in querySelectorAll('.$os')) {
      elem.hidden = !shouldShow; // Show or hide.
      elem.attributes['someAttribute'] = 'someValue';
    }
  }

  // Create an `Element` instance as html node. 
  var elem2 = Element.html(
    '<p>Creating <em>is</em> easy!</p>',
    );

  // Add the `Element` instance to html node with document tag.
  document.body!.children.add(elem2);

  // add node
  querySelector('#inputs')!.nodes.add(elem);

  // replace the node
  querySelector('#status')!.replaceWith(elem);

  // Find a node by ID, and remove it from the DOM if it is found.
  querySelector('#expendable')?.remove();

  // Find a button by ID and add an event handler.
  querySelector('#submitInfo')!.onClick.listen((e) {

    final clickedElem = e.target;
    // When the button is clicked, it runs this code.
    submitData();
  });
}