void main(){

  var uri = 'ws://echo.websocket.org';

  // create a `WebSocket` instance.
  var webSocket = WebSocket(uri);

  // send message.
  webSocket.send('Hello from Dart!');

  // register a listener for message events
  webSocket.onMessage.listen((MessageEvent e) {
    print('Received message: ${e.data}');
  });

  
}