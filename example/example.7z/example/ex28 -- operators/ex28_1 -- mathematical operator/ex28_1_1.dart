void main(){
  int integer1 = 100;
  int integer2 = 200;

  printArithmeticalOperationResult(integer1, integer2);
}

void printArithmeticalOperationResult(int x,int y){
  print('x:$x\n');
  print('y:$y\n');
  print('-x:${-x}\n');
  print('x+y:${x+y}\n');
  print('x-y:${x-y}\n');
  print('x*y:${x*y}\n'); // mutliplication
  print('x/y:${x/y}\n'); // division
  print('x~/y:${x~/y}\n'); // integer division
}