/*
  `...` spread operator.
*/
// an example of spread operator
void main(){
  var list1 = [1, 2, 3];
  var list2 = [0, ...list1];
}