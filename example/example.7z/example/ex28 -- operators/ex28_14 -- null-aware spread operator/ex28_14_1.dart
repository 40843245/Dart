/*
  `...` spread operator.
*/
// an example of spread operator
void main(){
  List<int>? list1;
  var list2 = [0, ...?list1];
}