void main(){
  int integer1 = 10;

  printPrefixAndPostfixOperationResult(integer1);
}

void printPrefixAndPostfixOperationResult(int x){
  int y = 0;
  
  y = x++;
  printValues(1, x, y);

  y = ++x;
  printValues(2, x, y);

  y = x--;
  printValues(3, x, y);

  y = --x;
  printValues(4, x, y);
}

void printValues(int index,int x,int y){
  print('$index) x:$x\n'); 
  print('$index) y:$y\n');
}