void main(){
  int x = 3;
  print(x);
}