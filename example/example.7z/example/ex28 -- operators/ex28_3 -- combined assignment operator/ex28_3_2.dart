void main(){
  double double1 = 125.0;
  
  printCombinedAssignmentOperatorResult(double1);
}

void printCombinedAssignmentOperatorResult(double x){
  int index = 0;

  printValue(index++, x);

  x += 2;
  printValue(index++, x);

  x -= 3;
  printValue(index++, x);

  x *= 4;
  printValue(index++, x);

  x /= 5;
  printValue(index++, x);

  x %= 6;
  printValue(index++, x);

  x *= 7;
  printValue(index++, x);

  x *= 8;
  printValue(index++, x);

  int y = x as int;
  y ~/= 9;
  printValueY(index++, y);

  y >>>= 1;
  printValueY(index++ ,y);

  y <<= 4;
  printValueY(index++ ,y);

  y >>= 1;
  printValueY(index++ ,y);

  y |= 7;
  printValueY(index++ ,y);

  y += 100;
  printValueY(index++ ,y);

  y &= 15;
  printValueY(index++ ,y);

  y += 100;
  printValueY(index++ ,y);

  y ^= 15;
  printValueY(index++ ,y);
}

void printValue(int index, double x){
  print('$index) x:$x');
}

void printValueY(int index, int y){
  print('$index) y:$y');
}