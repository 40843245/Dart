void main(){
  int integer1 = 5;
  int integer2 = 15;
  int integer3 = 20;

  compare(integer1);
  compare(integer2);
  compare(integer3);
}

void compare(int x){
    print('x is equal to $x\n');
    if(isLessThan10(x) || isLargerThan15(x)){
      print('The statement: $x < 10 || $x > 15 is true\n');
    }else{
      print('The statement: $x < 10 || $x > 15 is false\n');
    }

    if(isLargerThan100(x) && isLargerThan15(x)){
      print('The statement: $x > 100 || $x > 15 is true\n');
    }else{
      print('The statement: $x > 100 || $x > 15 is false\n');
    }
}

bool isLessThan10(int x){
  print('x = $x\n');
  return x < 10;
}

bool isLargerThan15(int y){
  print('y = $y\n');
  return y > 15;
}

bool isLargerThan100(int z){
  print('z = $z\n');
  return z > 100;
}