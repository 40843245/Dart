void main(){
  bool tf1 = false;
  
  // `!` logical NOT operator 
  bool tf2 = !tf1;

  // `||` logical OR operator
  bool tf3 = tf1 || tf2;

  // `||` logical OR operator
  bool tf4 = tf1 && tf2;
}