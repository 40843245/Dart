void main(){
  int integer1 = 100;
  int integer2 = 2;

  printBitwiseOperatorResult(integer1, integer2);  
}

void printBitwiseOperatorResult(int x,int y){
  print('x:$x\n');
  print('y:$y\n');
  print('x<<y:${x<<y}\n');
  print('x>>y:${x>>y}\n');
  print('x>>>y:${x>>>y}\n');
}