void main(){
  var fruits = [];
  assert(fruits.isEmpty);
}