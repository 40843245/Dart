void main(){
  final fruits = <String>['apple', 'orange', 'pear'];
  assert(fruits.length == 3);
}