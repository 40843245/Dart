void main(){
  final fruits = <String>['apple', 'orange', 'pear'];
  assert(fruits.isNotEmpty);
}