void main(){
  final list1 = List.filled(3, 'a'); // Creates: [ 'a', 'a', 'a' ]
}