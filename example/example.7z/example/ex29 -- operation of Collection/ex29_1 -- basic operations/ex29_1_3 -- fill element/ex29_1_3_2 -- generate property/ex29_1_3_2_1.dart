void main(){
  // Creates: [ 'a0', 'a1', 'a2' ]
  final list1 = List.generate(3, (index) => 'a$index');
}