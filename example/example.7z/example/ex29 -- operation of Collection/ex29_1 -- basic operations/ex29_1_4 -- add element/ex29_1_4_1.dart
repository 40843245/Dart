void main(){
  final fruits = ['apple', 'orange', 'pear'];
  fruits.add('peach');
  fruits.addAll(['kiwi', 'mango']);
  fruits.insert(0, 'peach');
  fruits.insertAll(0, ['kiwi', 'mango']);
}