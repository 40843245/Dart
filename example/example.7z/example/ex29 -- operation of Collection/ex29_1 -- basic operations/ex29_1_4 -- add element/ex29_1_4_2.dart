void main(){
  final gifts = {'first': 'partridge'};
  gifts['second'] = 'turtle doves';
  gifts.addAll({
    'second': 'turtle doves',
    'fifth': 'golden rings',
  });
  gifts.addEntries([
    MapEntry('second', 'turtle doves'),
    MapEntry('fifth', 'golden rings'),
  ]);
}