void main(){
  final fruits = <String>['apple', 'orange', 'pear'];
  // Remove the value 'pear' from the list.
  fruits.remove('pear');
  // Removes the last element from the list.
  fruits.removeLast();
  // Removes the element at position 1 from the list.
  fruits.removeAt(1);
  // Removes the elements with positions greater than
  // or equal to start (1) and less than end (3) from the list.
  fruits.removeRange(1, 3);
  // Removes all elements from the list that match the given predicate.
  fruits.removeWhere((fruit) => fruit.contains('p'));
}