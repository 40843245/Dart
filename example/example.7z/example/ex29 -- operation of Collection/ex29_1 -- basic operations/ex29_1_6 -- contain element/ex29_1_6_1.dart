void main(){
  final fruits = {'apple', 'orange', 'pear'};
  if(fruits.contains('apple')){
    print('$fruits contain at least one apples.\n');
  }else{
    print('$fruits contain zero apples.\n');
  }
}