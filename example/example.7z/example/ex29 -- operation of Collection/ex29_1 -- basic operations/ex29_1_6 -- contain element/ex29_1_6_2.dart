void main(){
  final gifts = {'first': 'partridge'};
  assert(gifts.containsKey('fifth'));
}