void main(){
  final gifts = {'first': 'partridge'};
  assert(gifts.containsValue('partridge'));
}