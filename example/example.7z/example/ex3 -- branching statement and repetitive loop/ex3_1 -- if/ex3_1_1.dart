/*
   branching statement -- `if`
*/
void main(){
  int year = 2000;
  if (year >= 2001) {
    print('21st century');
  } else if (year >= 1901) {
    print('20th century');
  } else {
    print('before than 20th century');
  }
}