/*
   branching statement -- `if` 
   `if` also support `case` clause 
*/
void main(){
  var [] pair = (2,3);
  if (pair case [int x, int y]) {
    print('Was coordinate array $x,$y');
  } else {
    throw FormatException('Invalid coordinates.');
  }
}