/*
   branching statement -- trinary operator `? :` 
*/
void main(){
  var integer1 = 5;
  var integer2 = 4;
  var integer3 = ( integer1 > 5 ) ? integer1 : integer2;
}