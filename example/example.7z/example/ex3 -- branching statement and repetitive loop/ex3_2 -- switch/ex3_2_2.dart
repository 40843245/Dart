/*
   branching statement -- `switch` - `case` clause 
*/
void main(){
  int number = 1;
  switch (number) {
    // Constant pattern matches if 1 == number.
    case 1:
      print('one');
    // Constant pattern matches if 1 == number.
    case 2:
      print('two');
  }
}