/*
  repetive loop -- `for` used as `foreach` in C++
*/
void main(){
  var flybyObjects
  for (final object in flybyObjects) {
    print(object);
  }
}