/*
  repetive loop -- `for`
*/
void main(){
  for (int month = 1; month <= 12; month++) {
    print(month);
  }
}