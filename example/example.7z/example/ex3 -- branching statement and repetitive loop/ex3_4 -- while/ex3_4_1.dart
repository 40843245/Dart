/*
   repetive statement -- `while`
*/
void main(){
  int year = 2001;
  while (year < 2016) {
    year += 1;
  }
}