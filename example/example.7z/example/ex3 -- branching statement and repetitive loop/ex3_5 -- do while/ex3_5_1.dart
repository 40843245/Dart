void main(){
  var counter = 1;
  do{
    print("$counter\t");
    counter++;
  }while(counter<10);
  print("\n$counter");
}