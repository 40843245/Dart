/*
  use of `continue` keyword.
*/
void main(){
  var counter = 1;
  while(counter < 10){
    print("$counter\t");
    if(counter == 5){
      print("\nnow, we continue the loop by break keyword.\n")
      continue;
    }    
    print("$counter\t\n");
    counter++;
  }
  print("now $counter\n");
}