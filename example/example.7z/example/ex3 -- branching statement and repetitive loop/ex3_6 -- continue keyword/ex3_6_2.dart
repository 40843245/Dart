/*
  use of `continue` keyword.
*/
void main(){
  var command = 'OPEN';
  switch (command) {
    case 'OPEN':
      executeOpen();
      continue newCase; // Continues executing at the `newCase` label.

    case 'DENIED': // Empty case falls through.
    case 'CLOSED':
      executeClosed(); // Runs for both DENIED and CLOSED,

    newCase: // define a `newCase` label
    case 'PENDING':
      executeNowClosed(); // Runs for both OPEN and PENDING.
  }
}