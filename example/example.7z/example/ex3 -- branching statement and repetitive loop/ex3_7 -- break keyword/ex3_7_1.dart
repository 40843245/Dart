/*
  use of `break` keyword.
*/
void main(){
  var counter = 1;
  while(counter < 10){
    print("$counter\t");
    if(counter == 5){
      print("\nnow, we exit the loop by break keyword.\n")
      break;
    }    
    print("$counter\t\n");
    counter++;
  }
  print("now $counter\n");
}