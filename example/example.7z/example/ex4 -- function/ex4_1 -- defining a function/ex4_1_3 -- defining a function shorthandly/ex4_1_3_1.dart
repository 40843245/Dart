bool isNoble(int atomicNumber) => atomicNumber < 10;

void main(){
  var result = isNoble(20);
}