// foo function will always return null.
foo() {}