// foo function will always return a record ('something', 42).
(String, int) foo() {
  return ('something', 42); // boxing technique
}

void main(){
  var (something,someInteger) = foo () // unboxing technique.
}