/*
A synchronous generator.

+ Feature:
  A synchronous generator will always return an `Iterable` object.

+ Implementation:
  To implement a synchronous generator function, mark the function body (just before the function body block (i.e. { } ) as sync*, and use yield statements to deliver values.
*/
// an example of a synchronous generator function
Iterable<int> naturalsTo(int n) sync* {
  int k = 0;
  while (k < n) yield k++;
}