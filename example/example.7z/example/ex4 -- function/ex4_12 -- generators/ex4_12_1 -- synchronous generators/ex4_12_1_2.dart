/*
A synchronous generator.

+ Feature:
  A synchronous generator will always return an `Iterable` object.

+ Implementation:
  To implement a synchronous generator function, mark the function body (just before the function body block (i.e. { } ) as sync*, and use yield statements to deliver values.
*/

/*
# improvement of a synchronous generator function

> [!TIP]
> If your generator is recursive, you can improve its performance by using yield*.
*/
// an example of a synchronous generator function (improved version)
Iterable<int> naturalsDownFrom(int n) sync* {
  if (n > 0) {
    yield n;
    yield* naturalsDownFrom(n - 1);
  }
}