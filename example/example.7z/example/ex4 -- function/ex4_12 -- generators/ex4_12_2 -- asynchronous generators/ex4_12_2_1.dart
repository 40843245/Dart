/*
An asynchronous generator.

+ Feature:
  An asynchronous generator will always return an `Stream` object.

+ Implementation:
  To implement a synchronous generator function, mark the function body (just before the function body block (i.e. { } ) as sync*, and use yield statements to deliver values.
*/
// an example of an asynchronous generator function
Stream<int> asynchronousNaturalsTo(int n) async* {
  int k = 0;
  while (k < n) yield k++;
}