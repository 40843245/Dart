/*
External function:
+ intro:
  An external function is a function whose body is implemented separately from its declaration. 
  Include the external keyword before a function declaration, like so.
*/
// an example of an external function.
external void someFunc(int i);