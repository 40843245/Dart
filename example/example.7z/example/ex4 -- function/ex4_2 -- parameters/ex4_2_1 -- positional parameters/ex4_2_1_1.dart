/*
  example of function with positional parameters.
*/
bool isNoble(int atomicNumber) {
  return atomicNumber < 20;
}