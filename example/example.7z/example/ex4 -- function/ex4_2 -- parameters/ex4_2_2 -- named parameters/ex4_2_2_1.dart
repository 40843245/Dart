/*
  example of function with named parameters.
*/
/// Sets the [bold] and [hidden] flags ...
void enableFlags({bool? bold, bool? hidden}) {
  // TODO
}

void main(){
  enableFlags(bold: true, hidden: false);
}