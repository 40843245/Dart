/*
  example of function with named parameters with default value.
*/
/// Sets the [bold] and [hidden] flags ...
void enableFlags({bool bold = false, bool hidden = false}) {
  //...
}

void main(){
  // bold will be true; hidden will be false.
  enableFlags(bold: true);
}