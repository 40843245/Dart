/*
  example of function with reqired named parameters.
*/
/*
If you instead want a named parameter to be mandatory, requiring callers to provide a value for the parameter, annotate them with required.
*/
const Scrollbar({super.key, required Widget child});