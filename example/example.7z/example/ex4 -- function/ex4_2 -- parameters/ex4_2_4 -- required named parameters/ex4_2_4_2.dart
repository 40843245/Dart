/*
  example of function with reqired named parameters.
*/
/*
A parameter marked as required can still be nullable.
*/
const Scrollbar({super.key, required Widget? child});