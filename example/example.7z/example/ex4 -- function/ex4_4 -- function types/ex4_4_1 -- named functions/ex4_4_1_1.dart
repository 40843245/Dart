void greet(String name, {String greeting = 'Hello'}) => print('$greeting $name!');

// Store `greet` in a variable and call it.
void Function(String, {String greeting}) g = greet;

void main(){
  g('Dash', greeting: 'Howdy');
}