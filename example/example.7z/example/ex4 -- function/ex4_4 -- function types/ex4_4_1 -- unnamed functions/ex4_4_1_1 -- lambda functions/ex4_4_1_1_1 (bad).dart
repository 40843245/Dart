// a bad example of use of lambda function.
void main() {
  var localFunction = () {
    // ...
  };
}