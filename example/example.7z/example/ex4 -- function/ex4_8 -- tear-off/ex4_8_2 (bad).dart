/*
When you refer to a function, method, or named constructor without parentheses, Dart creates a _tear-off_. 
This is a closure that takes the same parameters as the function and invokes the underlying function when you call it. 
If your code needs a closure that invokes a named function with the same parameters as the closure accepts, 
don't wrap the call in a lambda. 
Use a tear-off.
*/

// bad
void main(){
  var charCodes = [68, 97, 114, 116];
  var buffer = StringBuffer();

  // Function lambda
  charCodes.forEach((code) {
    print(code);
  });

  // Method lambda
  charCodes.forEach((code) {
    buffer.write(code);
  });
}