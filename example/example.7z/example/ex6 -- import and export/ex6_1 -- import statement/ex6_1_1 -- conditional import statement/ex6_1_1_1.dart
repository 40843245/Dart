/*
Here's what that code does:

- In an app that can use `dart:io` (for example, a command-line app), import `src/hw_io.dart`.
- In an app that can use `dart:js_interop` (a web app), import `src/hw_web.dart`.
- Otherwise, import `src/hw_none.dart`.
*/
import 'src/hw_none.dart' // Stub implementation
    if (dart.library.io) 'src/hw_io.dart' // dart:io implementation
    if (dart.library.js_interop) 'src/hw_web.dart'; // package:web implementation