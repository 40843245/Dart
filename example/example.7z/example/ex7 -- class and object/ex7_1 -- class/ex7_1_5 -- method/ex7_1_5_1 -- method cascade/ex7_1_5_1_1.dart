class Animal{
  String name;
  double weight;
  double height;
  
  Animal(this.name,this.weight,this.height);

  double bmi(){
    return this.weight / ( this.height * this.height );
  }

  void say(String message){
    print('An animal ${this.name} says ${message}\n');
  }

  void eat(String foodName){
    print('An animal ${this.name} eat ${foodName}\n');
  }
}

void main(){
  Animal cat = Animal('cat',20.0,30.0);
  cat..say('WTF')..eat('fish'); 
}

