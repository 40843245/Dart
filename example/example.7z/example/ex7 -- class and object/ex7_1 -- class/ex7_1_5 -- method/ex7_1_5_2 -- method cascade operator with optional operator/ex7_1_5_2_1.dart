class Animal{
  String name;
  double weight;
  double height;
  
  Animal(this.name,this.weight,this.height);

  double bmi(){
    return this.weight / ( this.height * this.height );
  }

  void say(String message){
    print('An animal ${this.name} says ${message}\n');
  }

  void eat(String foodName){
    print('An animal ${this.name} eat ${foodName}\n');
  }
}

void main(){
  Animal? cat1 = Animal('cat1',20.0,30.0);
  Animal? cat2;
  cat1?..say('WTF')..eat('fish'); 
  // ignore: dead_code
  cat2?..say('WTF')..eat('fish'); 
}

