class Animal {
  int eyes = 2; // Public field
  int _paws = 2; // Private field

  void _printEyes() { // Private method
    print(this.eyes);
  }

  void printPaws() { // Public method
    print(this._paws);
  }
}