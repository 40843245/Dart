// declaring simple enum class.
enum Color { 
  RED, 
  GREEN, 
  BLUE
}