// declaring simple enum class.
// trailing comma at last element is also okay.
enum Color { 
  RED, 
  GREEN, 
  BLUE, 
}