void main(){
  final favoriteColor = Color.BLUE;
  if (favoriteColor == Color.BLUE) {
    print('Your favorite color is blue!');
  }
}