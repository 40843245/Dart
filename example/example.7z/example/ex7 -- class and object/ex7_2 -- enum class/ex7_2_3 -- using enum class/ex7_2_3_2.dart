/*
  illustrate how to use `switch` - `case` block for enum.
*/
/*
> [!WARNING]
>  you'll get a warning if you don't handle all of the enum's values.
*/
void main(){
  var favoriteColor = Color.BLUE;

  switch (favoriteColor) {
      case Color.RED:
        print('Red as roses!');
      case Color.GREEN:
        print('Green as grass!');
      default: // Without this, you see a WARNING.
        print(favoriteColor); // 'Color.blue'
    }
}