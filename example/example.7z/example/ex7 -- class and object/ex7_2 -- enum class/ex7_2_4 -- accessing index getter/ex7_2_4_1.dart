/*
  illustrate the use of `index` getter.
*/
void main(){
  assert(Color.RED.index == 0);
  assert(Color.GREEN.index == 1);
  assert(Color.BLUE.index == 2);
}