/*
  illustrate how to get a list of Color (returned type `List<Color>` by value property.   
*/
void main(){
  List<Color> colors = Color.values;
  assert(colors[2] == Color.blue);
}