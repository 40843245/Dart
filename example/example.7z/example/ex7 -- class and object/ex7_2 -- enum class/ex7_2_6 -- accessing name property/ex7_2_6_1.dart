/*
  illustrate how to get the name of property in enum class.
*/
void main(){
  print(Color.BLUE.name); // 'BLUE'
}