/*
  illustrate how to access a member for enum (like you would on a normal object).

  For `Vehicle` enum class, see example ex7_2_3.dart.
*/
void main(){
  print(Vehicle.car.carbonFootprint);
}