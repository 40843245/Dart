abstract class Vehicle {
  void moveForward(int meters);
}