abstract class Vehicle {
  int totalMeter = 0;
  void moveForward(int meters);
}

// Can be extended.
class Car extends Vehicle {
  int passengers = 4;

  @override
  void moveForward(int meters) {
    totalMeter += meters;
  }
}

// Can be implemented.
class MockVehicle implements Vehicle {
  @override
  void moveForward(int meters) {
    totalMeter += meters;
  }
}