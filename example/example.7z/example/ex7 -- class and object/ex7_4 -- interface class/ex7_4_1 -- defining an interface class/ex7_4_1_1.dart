interface class Vehicle {
  void moveForward(int meters) {
    // ...
  }
}