interface class Vehicle {
  void moveForward(int meters) {
    // ...
  }
}

// ERROR: Can't be inherited.
class Car extends Vehicle {
  int passengers = 4;
  // ...
}

// Can be implemented.
class MockVehicle implements Vehicle {
  @override
  void moveForward(int meters) {
    // ...
  }
}

void main(){
  // Can be constructed.
  Vehicle myVehicle = Vehicle();
}