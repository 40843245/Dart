abstract interface class Vehicle {
  void moveForward(int meters) {
    // ...
  }
  abstract int totalMeter;
}