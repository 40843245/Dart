abstract interface class Vehicle {
  void moveForward(int meters) {
    // ...
  }
  abstract totalMeter = 0;
}

// ERROR: Can't be inherited.
class Car extends Vehicle {
  int passengers = 4;
}

// Can be implemented.
class MockVehicle implements Vehicle {
  @override
  int totalMeter;

  MockVehicle(){
    this.totalMeter = 0;
  }
  
  @override
  void moveForward(int meters) {
    this.totalMeter += meters
  }
}

void main(){
  // Can be constructed.
  Vehicle myVehicle = Vehicle();
}