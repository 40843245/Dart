final class Vehicle {
  void moveForward(int meters) {
    // ...
  }
}