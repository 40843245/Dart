final class Vehicle {
  void moveForward(int meters) {
    // ...
  }
}

// ERROR: Can't be inherited.
class Car extends Vehicle {
  int passengers = 4;
  // ...
}

class MockVehicle implements Vehicle {
  // ERROR: Can't be implemented.
  @override
  void moveForward(int meters) {
    // ...
  }
}

void main(){
  // Can be constructed.
  Vehicle myVehicle = Vehicle();
}