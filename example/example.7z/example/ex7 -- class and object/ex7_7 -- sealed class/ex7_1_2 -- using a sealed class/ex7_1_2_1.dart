sealed class Vehicle {}

class Car extends Vehicle {}

class Truck implements Vehicle {}

class Bicycle extends Vehicle {}

class Van extends Vehicle {}

class RedVan extends Van {}

class GreenVan extends Van {}

String getVehicleSound(Vehicle vehicle) {
  // ERROR: The switch is missing the Bicycle subtype or a default case.
  return switch (vehicle) {
    Car() => 'vroom',
    Truck() => 'VROOOOMM',
  };
}

void main(){
  // ERROR: Can't be instantiated.
  Vehicle myVehicle = Vehicle();

  // Subclasses can be instantiated.
  Vehicle myCar = Car();
}