import 'amigo.dart';

// This is an error: Can not inherit a sealed class outside the library whose sealed class is defined at. 
class Bad extends Amigo {}

// But these are both fine: since there are no transitive restriction to library for a sealed class. 
class OtherLucky extends Lucky {}
class OtherDusty implements Dusty {}