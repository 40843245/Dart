mixin class Both {}

class UseAsMixin with Both {}
class UseAsSuperclass extends Both {}