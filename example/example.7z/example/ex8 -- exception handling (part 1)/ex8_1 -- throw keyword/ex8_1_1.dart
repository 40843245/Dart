void main(){
  // you can throw an exception from the instance of `Exception` class or subclass of `Exception` class.
  throw Exception('Expected at least 1 section');
}