void main(){
  // you can throw an exception from the instance of `Exception` class or subclass of `Exception` class.
  throw FormatException('Expected at least 1 section');
}