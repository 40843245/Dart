void main(){
  // you can throw an exception from the instance of `Error` class or subclass of `Error` class.
  throw Error();
}