void main(){
  // you can throw an exception from any instance.
  throw 'Out of llamas!';
}