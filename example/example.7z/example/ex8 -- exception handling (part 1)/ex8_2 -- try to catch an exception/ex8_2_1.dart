void main(){
  try {
    throw Exception();
  } on Exception{
    print("There is an exception.");
  }
}