void main(){
  try {
    throw Exception();
  } on Exception catch (ex){
    print("There is an exception. Exception: $ex");
  } catch (ex){
    print("There is an exception except from instance of `Exception` class or subclass or `Exception` class. $ex");
  }
}