void misbehave() {
  try {
    dynamic foo = true;
    print(foo++); // Runtime error
  } catch (ex) {
    print('misbehave() partially handled ${ex.runtimeType}.');
    rethrow; // Allow callers to see the exception.
  } finally {
    print("This block will always be executed here.");
  }
}

void main() {
  try {
    misbehave();
  } catch (ex) {
    print('main() finished handling ${ex.runtimeType}.');
  } finally {
    print("This block will always be executed here.");
  }
}