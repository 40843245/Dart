void main(){
  var text = 'This is a text';
  var number = 100;
  var urlString = 'https://dart.dev/language/error-handling';

  // Make sure the variable has a non-null value.
  assert(text != null);

  // Make sure the value is less than 100.
  assert(number < 100);

  // Make sure this is an https URL.
  assert(urlString.startsWith('https'));
}