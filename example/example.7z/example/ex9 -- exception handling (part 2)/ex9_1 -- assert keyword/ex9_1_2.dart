void main(){
  var urlString = 'https://dart.dev/language/error-handling';

  assert(urlString.startsWith('https'), 'URL ($urlString) should start with "https".');
}